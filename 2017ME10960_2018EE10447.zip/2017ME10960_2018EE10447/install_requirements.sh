conda install pytorch
conda install -c conda-forge seqeval
conda install -c conda-forge pickle5
conda install pandas
conda install r-sys
conda install unicodecsv
conda install torchvision
conda install pillow